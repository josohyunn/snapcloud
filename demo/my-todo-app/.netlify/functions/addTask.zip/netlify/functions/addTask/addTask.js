// netlify/functions/addTask/addTask.mjs
exports.handler = async (event, context) => {
  const { task } = JSON.parse(event.body);
  console.log(`Task added: ${task}`);
  return {
    statusCode: 200,
    body: JSON.stringify({ message: `Task added successfully: ${task} ` })
  };
};
